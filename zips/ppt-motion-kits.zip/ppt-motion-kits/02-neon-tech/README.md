# 02 네온 테크 (NEON TECH)

**용도: AI · 테크 스타트업 발표**

딥 네이비 위 시안·보라 네온. HUD 모서리 브래킷 카드, LED처럼 끊어진 막대, 모노스페이스 라벨, 스캔라인이 지나가는 배경.

## 클로드에게: 이 키트로 디자인 시스템 만들기
- Design System 아티팩트 이름: `방구석 모션 키트 · 네온 테크`
- 이 폴더의 `tokens.json`은 값을 바꾸지 말고 그대로 넣습니다. 글꼴 파일은 상위 `fonts/` 폴더의 Pretendard 세 개를 `fonts/`에 넣습니다.
- 이 README를 브랜드북으로 씁니다(지우지 말 것).
- `charts/`의 8개 파일을 컴포넌트로 등록합니다. `components/<이름>/preview.html`에 **한 글자도 바꾸지 말고** 넣고 첫 줄에만 카드 주석을 붙입니다.
  MotionBackground(bg) · MotionCounter(counter) · MotionBarV(bar-v) · MotionLine(line) · MotionBarH(bar-h) · MotionCompare(compare) · MotionTreemap(treemap) · MotionDonut(donut)
- `templates/` 6개(cover, kpi, chart, statement, split, closing)도 같은 경로로 넣어둡니다. **덱을 만드는 클로드는 이 템플릿 마크업을 그대로 복사해서 글자와 데이터만 바꿉니다.**

## 클로드에게: 발표 덱 만들기 (Slides)
1. **슬라이드는 templates를 복사해서 만듭니다.** 레이아웃·색·글꼴·카드 모양은 템플릿과 똑같이 둡니다. 차트 슬라이드는 `chart.html`의 뼈대에 원하는 차트만 바꿔 넣습니다.
2. **첫 번째 자식은 항상 움직이는 배경**: `charts/bg.html` 전체를 `<x-embed style="position:absolute;left:0px;top:0px;width:1920px;height:1080px">`에 넣습니다. `mode`는 표지·지표·마무리 `'main'`, 차트 슬라이드 `'deep'`, 강조 슬라이드 `'accent'`. 빛 위치(glowX/glowY)는 슬라이드마다 조금씩 바꿉니다.
3. **차트**: 컴포넌트 `preview.html`의 첫 줄 주석을 뺀 문서 전체를 `<x-embed>`에 넣고 `const D` 블록만 고칩니다. 이 키트의 차트는 항상 `theme: 'dark'`로 둡니다(키트 색이 이미 입혀져 있습니다). `<x-embed>`는 `<section>`의 직속 자식, 슬라이드당 8개 이하, 하나당 16KB 이하.
4. **deck.json `faces`**는 아래를 그대로 씁니다. 디자인 시스템을 설치하면 Pretendard 경로는 `project/ds/<폴더>/fonts/...`가 됩니다.
```json
{
 "pretendard-black": {
  "family": "Pretendard Black",
  "src": "project/ds/<폴더>/fonts/Pretendard-Black.woff2"
 },
 "pretendard-extrabold": {
  "family": "Pretendard ExtraBold",
  "src": "project/ds/<폴더>/fonts/Pretendard-ExtraBold.woff2"
 },
 "pretendard-medium": {
  "family": "Pretendard Medium",
  "src": "project/ds/<폴더>/fonts/Pretendard-Medium.woff2"
 },
 "jetbrains-mono": {
  "family": "JetBrains Mono",
  "href": "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@700;800&display=swap"
 }
}
```
5. 제목은 주제가 아니라 **결론 문장**, 핵심 단어만 강조색. 슬라이드 하나에 메시지 하나.
6. 사용자가 준 숫자만 씁니다. 없으면 `[__]`로 비워두고 마지막에 목록으로 알려줍니다.

## 색
| 토큰 | 값 | 쓰는 곳 |
|---|---|---|
| `surface` | `#050816` | 기본 배경 |
| `surface-deep` | `#040611` | 차트 슬라이드 배경 |
| `ink` | `#EEF6FF` | 제목·숫자 |
| `ink-2` | `#8FA0C0` | 본문·라벨 |
| `foot` | `#5D6B88` | 푸터 |
| `accent` | `#22D3EE` | 강조 단어·외곽선·글로우 |
| `accent-light` | `#B8FBFF` | 그라데이션 밝은 쪽 |
| `accent-deep` | `#7C3AED` | 그라데이션 보라 쪽 |
| `accent-2` | `#A78BFA` | 라벨 슬래시 |
| `series-2` | `#F472B6` | 두 번째 데이터 계열 |

## 글꼴
표지·큰 숫자 Pretendard Black / 제목 Pretendard ExtraBold / 라벨·푸터 JetBrains Mono 800(구글 폰트) / 본문 Pretendard Medium
- Pretendard 세 글꼴은 파일 자체가 굵기를 가지고 있으므로 `font-weight:400`으로 둡니다.
- 크기: 150(표지) / 170(강조 슬라이드) / 80(제목) / 40(부제) / 32(본문) / 24(라벨·푸터). 24px보다 작게 쓰지 않습니다.

## 카드
반투명 남색 카드 + 네 모서리 시안 브래킷(HUD). 정확한 마크업은 `templates/chart.html`을 그대로 쓰세요.

## 덱 흐름 예시 (10장)
표지 → 핵심 숫자 3개(counter) → 성장(bar-v) → 추이(line) → 강조 한 문장(statement) → 항목 순위(bar-h) → 전후 비교(compare) → 구성(treemap) → 비율(donut, split) → 요청(closing)

## 참고
발표 화면과 공유 링크에서는 배경과 차트가 움직입니다. PPTX·PDF로 내보내면 마지막 화면으로 저장됩니다.
