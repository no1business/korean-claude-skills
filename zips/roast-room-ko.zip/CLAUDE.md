# Roast Room (한국판)

**한국판 규칙:** 사용자가 보는 모든 글(질문, 브리프, 자문위원 카드 내용, 의장 노트, 결론, 보고서)은 한국어로 쓴다. 카드의 필드 이름·선택형 값과 JSON 키·verdict label은 영어 그대로 둔다. 자세한 규칙은 `.claude/skills/roast-room/SKILL.md`의 "한국판 규칙". 사용자가 "원탁 켜줘", "로스트룸 켜줘"라고 하면 `npm start`를 백그라운드로 실행하고 http://localhost:4730 을 열라고 안내한다.

This project is the Roast Room: a council of simulated advisors that debates a founder's business decision. Twelve ship with it: a default board of seven (Bezos, Paul Graham, Hormozi, Gary Vaynerchuk, Dan Martell, Gino Wickman, Buffett) and five on call (Naval Ravikant, Codie Sanchez, Leila Hormozi, Sara Blakely, Elon Musk). Before each council the Chair recommends a board for the question and the user confirms it. The user can add more advisors.

- When the user brings a decision ("should I...", pricing, hiring, raising money, a new product, a pivot), run `/roast-room`. For a quick question to one advisor, use `/roast-room ask <seat> ...`.
- Every advisor and the default board live in `.claude/skills/roast-room/roster.json`. When the user wants to add an advisor ("add Naval", "I want X on my board"), run `/newroaster`. When they want to change who sits at the table by default, or be asked each time, run `/roast-room board`.
- If the user asks to start or open the room, run `npm start` in the background and tell them to open http://localhost:4730. It needs Node 20 or newer and nothing else.
- Councils are saved in `sessions/<date>-<decision>/`. The room plays them live as those files land. Follow `.claude/skills/roast-room/references/live-room.md` exactly so the room can read them.
- The seats are simulations built from public work. Never present a seat's words as something the real person said unless it is a verbatim quote with a source id from that seat's brain.
- Write the Chair's parts in plain Korean (한국어): short sentences, no hype, no filler. Keep the verdict in chat short enough to decide from at a glance; the full report goes in `verdict.md`, and the room's "Download PDF" button turns it into a branded PDF.
