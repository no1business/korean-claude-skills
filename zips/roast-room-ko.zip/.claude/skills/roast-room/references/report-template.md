# Report template (the Chair's verdict)

Written by the Chair in plain Korean (한국판: 아래 양식의 제목·문장을 모두 한국어로 쓴다. 판정 라벨은 한국어(진행 / 조건부 진행 / 다시 설계 / 보류 / 하지 마세요) 뒤에 괄호로 영어 라벨을 붙인다). No em dashes. No AI filler: state each point once, no tee-ups, no "here's the thing". Seat quotes keep their own voice. Keep the whole report under about 1,000 words; the round files hold the detail. Reference report: `sessions/2026-10-09-example-take-the-seed/verdict.md`.

```markdown
# Roast Room: [decision in a few words]

[date] · Seats: [list] · Rounds: [n] · Mode: [full | quick | named seats]

## Verdict: [GO | GO WITH CONDITIONS | RESHAPE | WAIT | DON'T DO IT]

**The call:** [one or two sentences the founder can act on, naming the option]

Option scores: [A] x.x · [B] x.x · [C] x.x · Support for the resolution x.x/10 · Confidence n/10 · Spread n · Vote: [n] endorse, [n] amend, [n] dissent
[Any override applied, in one line, or omit]

## Scorecard

| Seat | Weight | Final stance | [A] | [B] | [C] | Pillar score | Moved? | Their line |
|---|---|---|---|---|---|---|---|---|
| Buffett (money) | 3 | ... | 1 | 6 | 7 | 8 | gated B to C default | "[their one line for the founder]" |

Math: [one line per option]

## Why the council landed here

[3 to 5 bullets: the arguments that carried the room, each tagged with the seat and framework, e.g. (Hormozi, Value Equation)]

## Where they fought

[One short block per crux: the question, who was on each side, who moved and why, how it resolved or why it did not]

## Minority report

[The strongest dissent or minority view, in the seat's words, and what would have to be true for them to be right. If every seat agreed, say so and name the least-tested assumption instead.]

## Conditions

[Each checkable: a number, a date, or a test result. Say which must clear before the irreversible step.]

## What to do next

1. This week: [action] (owner)
2. [Next milestone with date]
3. [Decision date]

**Cheapest test:** [the smallest thing that checks the riskiest assumption before committing]
**Kill criteria:** [the signal that means stop, and what happens then]
**Revisit:** [when to bring this back to the council, and with which numbers]

---
공개 자료로 만든 AI 시뮬레이션이며, 실제 인물이 아니고 그들의 의견을 대변하지 않습니다.
```
