# 3라운드: 투표

## Bezos

SEAT: Bezos
VOTE: Endorse with amendment
OPTION SCORES: A 5/10 · B 8/10 · C 2/10
FINAL SCORE: 8/10
FINAL PILLAR SCORE: 8/10
AMENDMENT OR DISSENT: 중단 기준에서 "라떼 인상폭을 300원으로 낮춘다"는 빼야 합니다. 동네 가게가 4주 만에 가격을 올렸다가 내리면 단골 신뢰가 깎이고, 그러면 겉으로만 되돌릴 수 있는 문이 됩니다(Type 1 and Type 2 decisions, S063). 기준에 걸리면 세트부터 접고, 가격은 12주 동안 그대로 둔 채 단골 방문 수로 판단하도록 바꾸겠습니다.
ONE LINE FOR THE FOUNDER: 메뉴판 가격은 한 번 정하면 쉽게 못 바꾸는 문이고, 세트는 언제든 넣고 뺄 수 있는 문이에요. 실험은 세트로 하고 가격은 한 번에 정하세요.

## Graham

SEAT: Graham
VOTE: Endorse with amendment
OPTION SCORES: A 5/10 · B 8/10 · C 2/10
FINAL SCORE: 7/10
FINAL PILLAR SCORE: 7/10
AMENDMENT OR DISSENT: 아메리카노 기준선을 60%에서 55%로 내려 주세요. 55~60% 구간이면 라떼 인상분으로 92만 원을 못 채우니까, 그때는 바로 아메리카노 4,300원 안으로 가야 해요. 그리고 4주 점검 때 세트 주문 중 신규 디저트 구매 비율도 따로 세서, 절반이 안 되면 세트는 숨은 할인으로 보고 접어야 해요.
ONE LINE FOR THE FOUNDER: 단골이 이 가게를 정말 원하는지는 설문이 아니라 계산대에서 세어 봐야 알아요. 2주 동안 말로 권해 보고 몇 명이 받는지 직접 세 보세요(S096).

## Hormozi

SEAT: Hormozi
VOTE: Endorse with amendment
OPTION SCORES: A 6/10 · B 8/10 · C 1/10
FINAL SCORE: 8/10
FINAL PILLAR SCORE: 8/10
AMENDMENT OR DISSENT: 중단 기준에 "4주 뒤 라떼 손님의 디저트 동반 구매율이 인상 전보다 5%p 이상 안 오르면 세트를 없앤다"를 추가해 주세요. 디저트 전체 매출만 보면 기존 단골이 단품에서 세트로 옮긴 것만으로도 기준을 넘어서, 세트가 실제로 돈을 더 벌었는지는 알 수 없어요.
ONE LINE FOR THE FOUNDER: 계산해 보면 라떼 1,350잔 × 600원이 약 81만 원이에요. 150만 원까지 남은 부족분은 세트가 채워야 해요. "I never discount but I will change terms." (S046) (할인은 안 하지만 조건은 바꾼다). 세트에 할인은 절대 붙이지 말고 덤만 붙이세요.

## Gary V

SEAT: Gary V
VOTE: Endorse with amendment
OPTION SCORES: A 5/10 · B 8/10 · C 2/10
FINAL SCORE: 8/10
FINAL PILLAR SCORE: 7/10
AMENDMENT OR DISSENT: 가격은 맞게 짰는데 손님 관심을 끌 계획이 하나도 없어요. 11월 2일부터 알바가 커피 내리는 15초를 주 3개, 30분 안에 찍어서 올리고(Document, Don't Create, S142), 4주 점검에 "음료 손님 중 디저트 같이 사는 비율"을 넣어 주세요.
ONE LINE FOR THE FOUNDER: 1,800원 집들 옆에서 손님이 비교하는 숫자는 아메리카노 하나예요. 그 4,000원은 지키시고, 이번 주부터 매일 "왜 여기서 마셔야 하는지"를 보여 주세요(Day Trading Attention, S096).

## Martell

SEAT: Martell
VOTE: Endorse with amendment
OPTION SCORES: A 5/10 · B 7/10 · C 2/10
FINAL SCORE: 7/10
FINAL PILLAR SCORE: 6/10
AMENDMENT OR DISSENT: 지금 초안은 다음 할 일 세 개가 전부 사장님 몫이에요. 그러면 모든 일이 결국 사장님한테 몰려요. 두 가지를 넣어 주세요. 첫째, 세트 권하는 멘트는 알바 2명이 맡고, 성과는 세트 첨부율 10% 하나로 매주 봐요. 둘째, 늘어난 이익에서 월 50만 원을 알바 시간에 써서 사장님 근무를 주 5.5일로 줄여요. 70만 원을 모아도 80만 원이 남으니 그 돈으로 충분해요.
ONE LINE FOR THE FOUNDER: 사장님 시급은 지금 1만 1천 원이에요(Buyback Rate, S018). 가격을 올려서 번 돈은 사장님 시간을 사는 데 먼저 쓰세요. "If every road leads to you, you're the traffic jam." (S123) (모든 길이 너로 통하면 네가 교통체증이다)

## Wickman

SEAT: Wickman
VOTE: Endorse with amendment
OPTION SCORES: A 6/10 · B 8/10 · C 2/10
FINAL SCORE: 8/10
FINAL PILLAR SCORE: 8/10
AMENDMENT OR DISSENT: 세트를 기존 완제품으로만 꾸리고 사장님 추가 시간을 주 1시간 이하로 묶은 건 제 걱정을 정확히 막아 줬어요. 다만 세트 덤 발주와 진열, 안내 멘트는 알바 한 명이 맡도록 이름을 정하고, Scorecard는 4주 뒤에 한 번이 아니라 매주 월요일에 사장님이 봐야 합니다.
ONE LINE FOR THE FOUNDER: 주 66시간 일하는 사장님이 혼자 다 붙들고 있으면 이번 인상도 오래 못 갑니다. 이번 주에 세트 담당 알바 이름부터 정하세요.

## Buffett

SEAT: Buffett
VOTE: Endorse with amendment
OPTION SCORES: A 6/10 · B 8/10 · C 2/10
FINAL SCORE: 8/10
FINAL PILLAR SCORE: 8/10
AMENDMENT OR DISSENT: 3번 조건에 "폐기액이 디저트 매출의 5% 안"을 넣어 주세요. 세트 매출이 늘어도 버리는 게 같이 늘면 남는 게 없어요. 그리고 통장이 400만 원에 닿으면 다른 일은 다 멈추고 세트부터 접는다고 미리 정해 두세요. 부가세 내는 달이 제일 얇습니다.
ONE LINE FOR THE FOUNDER: 가격표 때문에 망하지는 않습니다. 망하는 건 단골이 한꺼번에 빠질 때와 통장이 비어 있을 때예요. 매달 70만 원은 꼭 따로 떼어 두세요. 물이 빠졌을 때 벌거벗고 있으면 안 되니까요.

## Chair

| 자문위원 | 수정안 | 채택 | 이유 |
|---|---|---|---|
| 베조스 | 중단 시 가격은 내리지 말고 세트부터 접기, 가격은 12주 유지 | 채택 | 반대한 자문위원이 없고, 가격을 올렸다 내리는 비용에 대한 반론이 없었어요. |
| 폴 그레이엄 | 아메리카노 기준선 60% → 55% | 미채택 | 게리 바이너척·댄 마텔·베조스가 60%, 버핏도 같은 선(라떼류 40%)을 잡았어요. 소수 의견에 남겨요. 신규 디저트 구매 비율 측정은 채택해요. |
| 호르모지 | 디저트 동반 구매율 5%p 미상승 시 세트 중단 | 채택 | 디저트 전체 매출만으로는 갈아타기를 못 걸러낸다는 지적에 반론이 없었어요. |
| 게리 바이너척 | 알바가 15초 영상 주 3개, 동반 구매율 점검 | 채택 | 사장님 시간을 쓰지 않는 방식이라 댄 마텔의 시간 조건과 충돌하지 않아요. |
| 댄 마텔 | 세트 멘트는 알바 담당, 월 50만 원으로 사장님 주 5.5일 | 채택 | 버핏의 월 70만 원 적립과 함께 감당 가능하다는 계산에 반론이 없었어요. |
| 지노 위크먼 | 세트 담당 알바 지정, Scorecard 매주 월요일 | 채택 | 댄 마텔 수정안과 같은 방향이에요. |
| 버핏 | 폐기액 5% 이내, 통장 400만 원이면 세트 즉시 중단 | 채택 | 반대 의견이 없었어요. |
