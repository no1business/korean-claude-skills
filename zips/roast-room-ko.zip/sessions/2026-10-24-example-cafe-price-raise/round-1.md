# 1라운드: 첫 의견

## Bezos

SEAT: Bezos (Strategy and decisions)
STANCE: Yes
OPTION SCORES: A 5/10 · B 8/10 · C 2/10
PILLAR SCORE: 8/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B로 가되, 4주 동안 두 가지 숫자를 보는 실험으로 돌리세요. 라떼·시그니처 판매량, 그리고 디저트 세트 주문 비율입니다.

WHY:
1. 문부터 가려야 합니다 (Type 1 and Type 2 decisions, S063). 가격표는 서류로만 보면 되돌릴 수 있는 문이죠. 그런데 동네 단골 카페에서 아메리카노 값을 올렸다가 다시 내리면 "흔들리는 가게"라는 인상이 남습니다. 겉으로는 되돌릴 수 있어 보여도 실제로는 한 방향 문에 가깝습니다. A는 손님 절반인 단골 전원에게 한꺼번에 그 문을 엽니다. B는 아메리카노 4,000원을 기준점으로 남겨둡니다. 그래서 라떼나 세트 구성이 틀렸으면 조용히 고치면 됩니다. "Type 2 decisions can and should be made quickly by high judgment individuals or small groups." (S063) (되돌릴 수 있는 결정은 판단력 있는 한 사람이 빨리 내려야 한다)
2. 숫자로 봐도 B가 낫습니다. 원가율이 32%에서 37%로 오르면서 월 1,800만 원 매출에서 이익이 약 90만 원 사라졌습니다. 제 가정은 월 약 4,000잔이고, 그중 절반이 아메리카노입니다. A로 가면 잔당 500원이 붙어 매출이 약 200만 원 늘어납니다. 하지만 판매량이 10% 빠지면 순증은 약 95만 원이고, 5% 빠져야 겨우 150만 원 선입니다. B는 라떼·시그니처 2,000잔에 평균 600원을 올려 약 120만 원을 법니다. 여기에 세트 15%가 붙어 세트당 3,000원씩 더 팔리면(가정) 매출이 약 180만 원, 원가를 빼고 약 110만 원이 남습니다. 아메리카노 단골을 건드리지 않고도 150만 원을 넘깁니다.
3. 10년 뒤에도 변하지 않을 것에 걸어야 합니다 (What's not going to change, S029). 단골이 매일 마시는 한 잔 값이 공정하고 일정했으면 하는 마음은 바뀌지 않습니다. 1,800원 프랜차이즈와 정면으로 비교되는 메뉴가 아메리카노입니다. 거기는 그대로 두고, 차별화가 되는 메뉴에서 값을 받으세요. C는 매달 90만 원을 잃으면서 기다리는 선택입니다. "being slow is going to be expensive for sure" (S064) (느린 건 확실히 비싸다)

THE RISK I SEE: 디저트 세트가 15%까지 안 붙는 경우입니다. 그러면 B는 라떼 인상분 120만 원만 남아서 목표에 못 미칩니다.

WHAT WOULD CHANGE MY MIND: POS를 봤는데 아메리카노가 전체 잔 수의 30%도 안 된다면 A로 가겠습니다. 그 정도면 기준점을 지키는 의미가 작고, A가 더 단순합니다.

WHAT I'D DO THIS WEEK: 지난 3개월 POS에서 메뉴별 잔 수를 뽑으세요. 단골이 실제로 무엇을 마시는지 표 한 장으로 정리하면 됩니다.

QUESTION FOR THE FOUNDER: 단골 절반이 매일 시키는 메뉴가 아메리카노인가요, 라떼인가요?

## Graham

SEAT: Graham (Product and startups)
STANCE: Conditional yes
OPTION SCORES: A 6/10 · B 8/10 · C 2/10
PILLAR SCORE: 7/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B로 가되, 아메리카노는 4,000원으로 묶어 두고 라떼·시그니처만 600원 올리고 디저트 세트를 붙이세요.

WHY:
1. 첫 질문은 늘 "누가, 얼마나 간절히 원하나"예요(S098). 1,800원짜리 프랜차이즈 아메리카노와 정면으로 비교당하는 메뉴는 바로 아메리카노예요. 이 집에서만 마실 수 있는 건 라떼와 시그니처고요. 가격은 진짜로 원하는 쪽에 올려야 하는데, A는 가장 비교당하기 쉬운 메뉴에까지 가격을 올려요.
2. 계산해 보죠. 가정은 월 3,900잔(150잔 × 26일), 잔당 평균 약 3,460원, 원가율 37%예요. A는 판매량이 그대로면 월 공헌이익이 약 195만 원 늘어요. 그런데 판매량이 7% 줄면 +122만 원, 10% 줄면 +91만 원이에요. 줄어든 방문만큼 디저트 매출도 빠지고요. 그러니 브리프가 가정한 판매량 감소 폭에서는 A가 목표 150만 원에 못 미쳐요. B는 라떼·시그니처를 전체 잔의 절반으로 잡으면 600원 × 1,950잔 = 117만 원이에요. 여기에 세트 15%(585건)가 건당 2,000원씩 남기면 약 117만 원이 더해지고요. 이탈은 적고 목표는 넘어요.
3. 가격 결정은 되돌릴 수 있어요. "you can always change your prices later though if you want to lower your prices no one's gonna complain"(S009)(가격은 나중에 언제든 바꿀 수 있고, 내리는 데 불평할 사람은 없다). 겁낼 문은 아니라는 뜻이에요. 다만 이 카페는 스타트업이 아니라 현금흐름 사업이라 성장률 잣대는 내려놓고, 이번 판단은 공헌이익과 단골 유지로 봤어요.

THE RISK I SEE: 실제로 아메리카노 비중이 60~70%라면 B로 올라가는 매출이 50만~70만 원에 그쳐서, 3개월 뒤에도 남는 게 없을 수 있어요.

WHAT WOULD CHANGE MY MIND: 메뉴별 판매 비중이요. 아메리카노가 전체 잔의 60%를 넘으면 A로 바꾸고, 단골에게는 쿠폰을 써서 기존 가격을 유지해 주세요.

WHAT I'D DO THIS WEEK: POS로 지난 4주 메뉴별 잔 수를 뽑고, 단골 20명에게 직접 "라떼가 4,800원이 되면 계속 오시겠어요?"라고 물어보세요. 손으로 하는 일인데, 그게 맞아요(S096).

QUESTION FOR THE FOUNDER: 하루 150잔 중 몇 잔이 아메리카노이고, 단골들은 주로 뭘 시키나요?

## Hormozi

SEAT: Hormozi (Offers, pricing, and sales)
STANCE: Yes
OPTION SCORES: A 6/10 · B 8/10 · C 1/10
PILLAR SCORE: 8/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B로 갑니다. 아메리카노 4,000원은 미끼로 그대로 두고, 라떼·시그니처는 600원 올리고, 디저트 세트는 할인 상품이 아니라 업셀로 설계하세요.

WHY:
1. 이건 가격 문제가 아니라 계산 문제예요. "This is a math problem not a Alex what should I price it at problem" (S015) (가격을 감으로 정하는 문제가 아니라 수학 문제다). 원가율이 5%p 오르면 1,800만 원 매출에서 매달 약 90만 원이 그냥 사라집니다. 그래서 C는 가만히 피 흘리는 선택이에요. A는 잔당 매출총이익이 약 2,180원에서 2,680원으로 올라서, 판매량이 18.7%까지 빠져도 본전입니다. 판매량이 5~10% 빠지면 순증은 월 60만~130만 원이고, 부가세를 빼면 목표 150만 원에 못 미쳐요. (가정: 월 26일 영업, 3,900잔, 잔당 평균 약 3,460원)
2. 머니 모델로 보면 B가 이깁니다(Money Model, S113). 아메리카노는 저가 프랜차이즈와 정면으로 비교되는 메뉴라서 손님을 끌어오는 미끼로 남겨 둡니다. 라떼는 사과 대 사과로 가격을 비교당하지 않는 메뉴예요. 비아메리카노가 절반이라고 가정하면 1,950잔 × 600원으로 월 약 110만 원이 생깁니다. 세트 주문 비율 15%면 585건이고, 그중 절반만 새로 생긴 디저트 매출이라 쳐도 개당 매출총이익 3,000원으로 월 약 90만 원이 더해져요. 합치면 월 200만 원 안팎입니다.
3. 할인하지 말고 조건을 바꾸세요. "I never discount but I will change terms." (S046) (나는 할인은 안 하지만 조건은 바꾼다). 세트는 "라떼 드시는 분은 이거 같이"처럼 묶어 파는 상품이지, 원래 디저트를 사던 단골에게 깎아 주는 메뉴가 아니에요.

THE RISK I SEE: 세트가 결국 할인 메뉴가 되는 겁니다. 원래 디저트를 사던 단골이 세트로 갈아타기만 하면 마진만 갉아먹어요.

WHAT WOULD CHANGE MY MIND: 아메리카노가 전체 잔수의 70%가 넘으면 B로 올라가는 잔이 너무 적어요. 그때는 A로 바꿉니다.

WHAT I'D DO THIS WEEK: POS에서 지난 4주치 메뉴별 판매 비중과 디저트를 같이 사는 비율을 뽑아서 위 계산에 실제 숫자를 넣으세요.

QUESTION FOR THE FOUNDER: 하루 150잔 중에 아메리카노가 정확히 몇 잔이에요?

## Gary V

SEAT: Gary V (Marketing and attention)
STANCE: Yes
OPTION SCORES: A 5/10 · B 8/10 · C 2/10
PILLAR SCORE: 8/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B로 가세요. 아메리카노 4,000원은 간판처럼 지키고, 라떼·시그니처 인상과 디저트 세트로 돈을 버는 겁니다.

WHY:
1. 손님 관심은 아메리카노 가격에서 시작됩니다. 1,800원짜리 두 곳 옆에서 사람들이 비교하는 숫자는 하나, 아메리카노예요. 이걸 4,500원으로 올리는 순간 단골이 프랜차이즈를 다시 볼 이유를 우리가 직접 주는 겁니다. Day Trading Attention(S096)으로 보면 아메리카노는 남는 메뉴가 아니라 손님을 끌어오는 메뉴입니다. "Before you can sell anything, you need somebody's attention." [S011, 2020] (뭘 팔든 먼저 누군가의 관심을 얻어야 한다)
2. 숫자로 따져봤습니다. 가정은 주 6일 기준 월 3,900잔, 원가율 37%예요. A는 판매량이 10% 빠지면 순이익이 약 63만 원, 5%만 빠져도 약 129만 원 늘어나는 데 그쳐서 목표 150만 원에 못 미칩니다. B는 라떼류를 전체 잔수의 40%로 보고 600원 올리면 약 65만 원이 늘고, 세트 주문 15%(월 585건)에서 건당 2,000원씩 더 남기면 약 117만 원이 늘어요. 합치면 약 180만 원입니다. 다만 세트 주문 비율과 라떼 비중은 아직 가정이에요.
3. 현금 600만 원이면 버틸 여유가 길지 않으니 지금은 당장의 매출이 우선입니다. "small businesses need to pander more to short term sales because of issues like cashflow." [S114, 2019] (소상공인은 현금 흐름 때문에 단기 매출에 더 신경 써야 한다) 그리고 가격을 위로 시험해 보는 것도 맞습니다. "ask for a little bit more money on the next scope just as a testing mechanism" [S005, 2019] (다음 건에서는 시험 삼아 조금 더 불러봐라). 시험은 아메리카노 말고 라떼에서 하세요.

THE RISK I SEE: 세트가 실제 객단가를 안 올리고, 원래 디저트를 사던 손님이 할인만 챙겨 가는 경우입니다. 그러면 B는 65만 원짜리 안이 됩니다.

WHAT WOULD CHANGE MY MIND: 판매 데이터에서 라떼·시그니처가 전체 잔수의 25%도 안 되면 B만으로는 숫자가 안 나옵니다. 그때는 A로 갑니다.

WHAT I'D DO THIS WEEK: 이번 주 안에 "아메리카노는 3년째 4,000원 그대로입니다" 문구를 계산대와 인스타그램에 올리세요. 원두값이 왜 올랐는지 사장님 이야기를 짧은 영상 3개로 찍어서 같이 올리고요. "Document. Don't create." [S143, 2016] (꾸며 만들지 말고 있는 그대로 기록해라)

QUESTION FOR THE FOUNDER: 지난달 판매 데이터에서 아메리카노와 라떼·시그니처 비율이 각각 몇 퍼센트였나요?

## Martell

SEAT: Martell (People, hiring, and founder time)
STANCE: Yes
OPTION SCORES: A 7/10 · B 4/10 · C 2/10
PILLAR SCORE: 7/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: A로 가세요. 다음 주에 전 메뉴 500원 인상하고, 메뉴는 하나도 늘리지 마세요.

WHY:
1. Buyback Rate (S018)로 사장님 한 시간 값을 계산해 봤어요. 재료비 37%면 666만 원, 월세 250만 원, 인건비 420만 원이에요. 수수료·공과금 같은 기타 비용을 150만 원으로 가정하면 사장님 몫은 약 314만 원이에요. 이걸 월 286시간(주 66시간)으로 나누면 시급 약 1만 1천 원, 최저시급이랑 거의 같아요. 4로 나누면 2,700원이라 지금은 누구한테 일을 넘길 돈이 없어요. 솔직히 이 상황에선 제 렌즈가 약해요. 그런데 "사람 쓸 여유가 없다"는 말은 대부분 가격을 제대로 못 받고 있다는 뜻이에요. 그러니까 첫 번째로 손볼 건 사람이 아니라 가격이에요.
2. 사장님 시간 기준으로 보면 A는 간판이랑 POS 바꾸는 데 반나절이면 끝나요. 하루 150잔 기준(월 4,500잔 가정)으로 판매량이 5~10% 줄어도 월 순이익이 약 120만~170만 원 늘어요. B는 디저트 세트 준비, 발주, 포장, 알바 교육 때문에 이미 주 66시간 일하는 사장님한테 주 5~7시간이 더 얹혀요(가정). C는 시간은 그대로인데 남는 돈만 계속 줄어요. "Entrepreneurs will not grow into pain." (S014, 감당 못 할 고통 쪽으로는 성장하지 않는다)
3. Buyback Loop (S020)의 Fill 단계예요. 늘어난 돈에서 월 50만 원을 떼서 알바 시간을 주 9~10시간 늘리고, 사장님 근무를 주 6일에서 5.5일로 줄이세요. "Most entrepreneurs think late nights are the cost of ambition. But that's actually the cost of a broken calendar." (S110, 늦게까지 일하는 건 야망의 대가가 아니라 망가진 일정표의 대가다)

THE RISK I SEE: 단골이 "왜 올랐냐"고 물을 때마다 사장님이 직접 설명하느라 가게에 붙잡히는 거예요. 알바 2명이 쓸 30초짜리 안내 멘트를 미리 만들어 두세요.

WHAT WOULD CHANGE MY MIND: 디저트 세트를 사장님 손 안 거치고 완제품 납품으로 받을 수 있고, 추가 시간이 주 1시간 아래라면 B 점수를 올릴게요.

WHAT I'D DO THIS WEEK: 3일 동안 15분 단위로 사장님 하루를 기록하는 시간·에너지 점검 (Time and Energy Audit, S057)을 하면서, 인상 안내문과 알바용 응대 멘트를 같이 준비하세요.

QUESTION FOR THE FOUNDER: 인상으로 매달 150만 원이 더 생기면, 그중 얼마를 사장님 주 6일, 하루 11시간을 줄이는 데 쓰실 건가요?

## Wickman

SEAT: Wickman (Operations and scaling)
STANCE: Yes
OPTION SCORES: A 8/10 · B 5/10 · C 2/10
PILLAR SCORE: 8/10
CONFIDENCE: 3/5
RUIN RISK: possible
DOOR: two-way

THE CALL: A로 갑니다. 다음 주에 전 메뉴를 500원씩 올리고 디저트 세트는 Issues List에 올려 둡니다.

WHY:
1. 이 문제는 Process 문제입니다(Six Key Components, S043). 원가율이 32%에서 37%로 올랐으니 월 매출 1,800만 원 기준으로 매달 약 90만 원이 새고 있어요. 근본 원인은 가격표 하나입니다. A는 메뉴판과 POS를 한 번만 바꾸면 되고, 아르바이트 2명에게 줄 규칙도 "전부 500원 올림" 하나예요. "Simple, practical. It does not have to be complex." (S025) (단순하고 실용적으로. 복잡할 필요가 없다)
2. B는 사장님이 새로 떠맡는 일이 너무 많아요. 메뉴별로 다른 인상폭, 새 세트 메뉴, 디저트 재고 관리, 아르바이트 교육까지 생기는데, 사장님은 이미 주 66시간을 일하고 있어요. 그 일을 맡을 사람이 사장님밖에 없는 구조입니다. 제가 계산해 보면(26일 영업, 하루 150잔, 판매량 5% 감소로 가정) A만으로 순이익이 월 약 140만 원 늘어요. 목표 150만 원에 거의 닿습니다. 여기에 세트 메뉴라는 반짝이는 것을 더할 이유가 없어요. "Until you maximize every opportunity in your sweet spot, there's no reason to look anywhere else." (S110) (핵심 영역의 기회를 다 살리기 전에는 다른 곳을 볼 이유가 없다)
3. 3년 동안 가격을 동결한 건 두려움에서 나온 결정입니다. "Most companies are under charging for their product or service" (S053) (대부분의 회사는 제품이나 서비스 값을 너무 적게 받는다)

솔직히 말씀드리면, 직원 3명짜리 가게는 제 렌즈가 원래 다루는 크기가 아닙니다. 그래도 단순하게 가자는 원칙은 여기서도 그대로 통해요.

THE RISK I SEE: 현금 600만 원으로는 월세와 인건비를 합한 670만 원을 한 달도 못 버팁니다. "Do you have six months cash reserves in your personal bank account and in your business bank account?" (S068) (개인 통장과 사업 통장에 6개월치 현금이 있습니까?) 판매량이 10%를 넘어 20% 이상 빠지면 이 가게는 두 달 안에 위험해집니다.

WHAT WOULD CHANGE MY MIND: 인상 후 4주 동안 주간 판매량이 15% 넘게 줄어드는 경우요.

WHAT I'D DO THIS WEEK: 주간 Scorecard 하나를 만드세요. 숫자는 "주간 잔 수, 단골 방문 수, 원가율" 세 개, 담당은 사장님입니다. 그리고 가격을 바꿔 붙이세요. Stay focused.

QUESTION FOR THE FOUNDER: 판매량이 15% 빠지면 가격을 되돌릴지, 버틸지, 지금 날짜를 정해 두실 수 있나요?

## Buffett

SEAT: Buffett (Money and capital)
STANCE: Conditional yes
OPTION SCORES: A 6/10 · B 8/10 · C 2/10
PILLAR SCORE: 8/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B로 가되, 4주 동안 라떼·시그니처 판매량이 12% 넘게 빠지면 인상 폭을 줄이는 조건을 붙입니다.

WHY:
1. C는 가장 위험한 선택입니다. 원가율이 32%에서 37%로 올랐으니 월 1,800만 원 매출에서 마진이 매달 90만 원씩 새고 있어요. 그런데 통장의 600만 원은 월세와 인건비를 합친 670만 원에도 못 미칩니다. "We must never write inadequately-priced policies in order to stay in the game. That policy is corporate suicide." (S097) (판에 남겠다고 값을 너무 싸게 받으면 안 된다. 그건 회사가 스스로 목숨을 끊는 일이다.) 업종이 다를 뿐 카페에도 똑같이 적용된다는 게 제 해석입니다.
2. 아메리카노는 원자재 같은 상품입니다. 300m 안에 1,800원짜리가 두 곳이나 있어요. "In a business selling a commodity-type product, it's impossible to be a lot smarter than your dumbest competitor." (S063) (원자재 같은 상품을 파는 사업에서는 가장 어리석은 경쟁자보다 훨씬 똑똑해지기가 불가능하다.) 가격 결정력이 있는 곳은 라떼와 시그니처예요 (Franchise versus commodity, S064).
3. 계산을 해보겠습니다. 가정은 이렇습니다. 월 26일 영업에 3,900잔, 잔당 평균 3,460원, 원가 1,280원. A안은 판매량이 10% 줄면 이익이 월 91만 원, 5% 줄면 143만 원 늘어납니다. 어느 쪽도 목표인 150만 원에 못 미쳐요. B안은 라떼류가 절반인 1,950잔이라고 보고 600원을 올리면 117만 원이 생기고, 세트 주문 15%에 잔당 마진 1,000원을 더하면 58만 원이 붙습니다. 합쳐서 170만 원 안팎이고, 단골이 매일 보는 아메리카노 가격은 건드리지 않아요 (Cost of capital is the second-best idea, S013).

THE RISK I SEE: 라떼 손님까지 프랜차이즈로 옮겨가고, 세트 메뉴 때문에 디저트 원가와 폐기가 늘어서 남는 게 없어지는 것입니다.

WHAT WOULD CHANGE MY MIND: 현재 판매에서 아메리카노 비중이 70%를 넘는다면 B안의 인상 효과는 60만 원도 안 됩니다. 그러면 A안이 낫습니다. A안은 판매량이 18.7% 줄어야 비로소 지금보다 나빠지니까요.

WHAT I'D DO THIS WEEK: 지난 4주 POS 자료를 뽑아서 메뉴별 잔 수와 디저트를 함께 사 간 비율을 원 단위로 정리하세요.

QUESTION FOR THE FOUNDER: 단골 중에 라떼를 마시는 손님이 몇 명이고, 그분들이 4,500원짜리 라떼를 5,100원에 사도 계속 오실 거라고 장담하실 수 있나요?

## Chair notes

**쟁점**
1. **아메리카노가 전체 잔 수에서 몇 %인가** (숫자 문제): B를 고른 베조스·그레이엄·호르모지·게리 바이너척·버핏 모두 "라떼·시그니처가 절반쯤"이라고 가정했어요. 이 비중이 60~70%를 넘으면 B의 인상 효과가 60만 원 안팎으로 줄어든다고 스스로 인정했어요.
2. **디저트 세트가 사장님 시간을 얼마나 잡아먹나** (운영·시간 문제): 댄 마텔과 지노 위크먼은 주 66시간 일하는 사장님에게 세트 준비·발주·교육이 얹히면 B가 무너진다고 봐요(A 지지). 나머지 다섯 명은 세트를 업셀로 보고 시간 비용을 따지지 않았어요.
3. **세트가 업셀인가, 숨은 할인인가** (가치 문제): 호르모지·게리 바이너척·버핏 모두 "원래 디저트 사던 단골이 세트로 갈아타기만 하면 마진이 깎인다"는 같은 위험을 짚었어요.

**만장일치 점검:** 5대 2로 갈렸고 C는 모두 1~2점이라 만장일치는 아니에요. 다만 C를 진지하게 변호한 사람이 없어요.

**형식:** 카드 7장 모두 필드를 다 채웠어요. 위크먼은 A에 RUIN RISK possible을 달았는데, 근거는 A 자체보다 현금 600만 원이 한 달 고정비에도 못 미친다는 점이에요.
