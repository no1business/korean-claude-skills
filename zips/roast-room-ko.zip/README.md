# 로스트룸 한국판 (Roast Room KO)

![로스트룸](docs/room.jpg)

사업 고민 하나를 던지면 버핏·베조스·호르모지 같은 **AI 자문단 7명**이 원탁에 앉아 3라운드 동안 토론하고, 선택지마다 점수를 매긴 결론을 **한국어 PDF 보고서**로 줍니다.

- 원본: [nateherkai/roast-room](https://github.com/nateherkai/roast-room) (MIT, AI Automation Society)
- 한국판: [방구석프로](https://bangpro.ai.kr) · 인스타그램 [@bangpro_ai](https://instagram.com/bangpro_ai)
- 설치 가이드(그림 포함): https://bangpro.ai.kr/guide/research-03

## 한국판에서 바뀐 것

- 자문위원 토론·의장 결론·보고서가 전부 **한국어**로 나와요. 금액은 원 단위, 한국 소상공인·1인 사업자 현실(부가세, 4대보험, 정부지원사업 등)에 맞춰 판단해요.
- 원탁 화면의 모든 버튼·안내 문구를 한국어로 바꿨어요.
- PDF 보고서에 한글 글꼴(Pretendard, SIL OFL)을 넣어 한글이 깨지지 않아요.
- 한국어 예시 토론 1개 포함: "동네 카페 커피값 인상" (`sessions/2026-10-24-example-cafe-price-raise/`)
- 자문위원이 인용하는 원문은 영어 그대로 두고 괄호로 뜻을 붙여요. 인용 검사 스크립트가 원문과 한 글자씩 대조해요.

## 필요한 것

- PC + [Claude Code](https://claude.com/claude-code) (Claude 요금제로 사용, API 키 필요 없음)
- [Node.js](https://nodejs.org) 20 이상

## 사용법

1. 이 폴더를 Claude Code로 열어요.
2. 원탁 화면 켜기: `npm start` → 브라우저에서 http://localhost:4730 (켜 둔 채로)
3. Claude Code에서 고민을 입력해요.

```
/roast-room 동네 카페를 3년째 하고 있어요. 월 매출 1,800만 원, 원가율이 32%에서 37%로 올랐어요.
전 메뉴 500원 인상 / 라떼만 인상 + 디저트 세트 / 가격 유지 중에 뭐가 나을까요?
현금은 600만 원, 3개월 안에 월 순이익 150만 원 늘리는 게 목표예요. 저는 전 메뉴 인상 쪽이에요.
```

4. 의장이 묻는 질문에 답하면 원탁에서 토론이 시작돼요. 끝나면 **PDF 받기**를 누르세요.

더 쓰는 법:
- `/roast-room --quick ...` 자문위원 4명, 2라운드. 작은 결정에 쓰면 사용량이 훨씬 적어요.
- `/roast-room ask buffett ...` 한 명에게만 물어보기
- `/newroaster 이름` 원하는 사람을 새 자문위원으로 추가 (그 사람의 공개 글·영상을 모아 만들어요)

## 안내

자문위원은 각 인물의 공개 자료로 만든 **AI 시뮬레이션**이에요. 실제 인물이 아니고, 그들의 의견을 대변하지 않으며, 이 프로젝트와 아무 관계가 없어요. 영어 원본 설명은 [README.en.md](README.en.md)에 있어요.

라이선스: MIT (원본과 동일). 한글 글꼴 Pretendard는 SIL Open Font License.
