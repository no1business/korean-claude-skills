---
name: youtube-agent-ko
description: >-
  유튜브 채널 운영을 돕는 한국판 스킬 묶음 (11개). 유튜브 대본 써줘, 후킹 써줘,
  첫 문장 뭐라고 하지, 쇼츠 대본, 제목 지어줘, 썸네일 문구, 클릭률이 낮아, 편집할
  구간 찾아줘, 자막 파일로 컷 편집, 챕터 만들어줘, 댓글 답장 써줘, 이번 주 업로드
  계획 짜줘, 콘텐츠 일정, 요즘 뭐가 터져, 떡상한 영상 분석, 경쟁 채널 분석, 시청
  지속률 분석, 어디서 이탈했어, 긴 영상에서 쇼츠 뽑아줘, 설명란·태그 써줘, 내 채널
  진단해줘, voice.md 만들어줘 같은 요청에 쓴다. Also: YouTube script, hook, title,
  thumbnail, retention, shorts, SEO, chapters, comments, channel audit.
---

# youtube-agent-ko (유튜브 자동화 스킬 한국판)

모든 결과물은 한국어로 쓴다. 한국 유튜브 시청자 기준으로 쓰고, 영어 예시는 한국 상황으로 바꾼다.

이 스킬은 11개 스킬을 하나로 묶은 것이다. 사용자의 요청을 보고 아래 표에서 맞는 스킬을 골라,
그 폴더의 `GUIDE.md`를 먼저 읽고 그대로 따른다. 파이썬 도구는 각 폴더 안에 있고, 이 스킬
폴더 기준 경로로 실행한다 (예: `python3 skills/yt-script/hookscore.py --hook "..."`).
요청이 여러 개에 걸치면 순서대로 둘 이상 써도 된다.

| 이런 요청이면 | 읽을 파일 |
| --- | --- |
| 대본, 후킹, 첫 문장, 쇼츠 대본 | `skills/yt-script/GUIDE.md` |
| 제목, 썸네일 문구, 클릭률 | `skills/yt-package/GUIDE.md` |
| 편집할 구간, 컷 편집, 자막 파일(srt) 정리 | `skills/yt-edit/GUIDE.md` |
| 댓글 정리·답장, 고정 댓글 | `skills/yt-comment/GUIDE.md` |
| 주간·월간 업로드 계획 | `skills/yt-plan/GUIDE.md` |
| 요즘 터진 영상, 경쟁 채널 분석 | `skills/yt-viral/GUIDE.md` |
| 시청 지속률, 이탈 구간 | `skills/yt-retention/GUIDE.md` |
| 긴 영상에서 쇼츠 뽑기 | `skills/yt-shorts/GUIDE.md` |
| 설명란, 태그, 검색어 | `skills/yt-seo/GUIDE.md` |
| 챕터(타임스탬프) | `skills/yt-chapters/GUIDE.md` |
| 채널 전체 진단 | `skills/yt-audit/GUIDE.md` |

## 내 말투 파일 (voice.md)

모든 스킬이 사용자의 말투 파일을 먼저 읽는다. 찾는 순서:
1. `~/.claude/youtube/voice.md`
2. 이 대화나 프로젝트 파일에 올라온 `voice.md`
3. 둘 다 없으면 사용자에게 **본인 영상 세 개의 대본(자막)**을 받아 `templates/voice.md` 양식대로
   새로 쓰고, 파일로 돌려준다. 클로드 앱(웹·모바일)에서는 대화가 바뀌면 파일이 사라지므로,
   "이 voice.md를 프로젝트 파일에 넣어두면 다음부터 다시 안 만들어도 돼요"라고 안내한다.

## 지키는 것

- 업로드는 하지 않는다. 이 스킬은 쓰고, 올리는 건 사용자가 한다.
- 숫자·결과·출처를 지어내지 않는다. 필요한 숫자가 없으면 묻거나 숫자 없이 쓴다.
- `hookscore.py` 점수는 참고용이다. 빠진 요소(숫자, 시청자 호명, 손해)를 짚는 체크리스트로 쓰고,
  "이 점수면 터진다"고 말하지 않는다.

## 원본

[Jakeschincariol/youtube-agent-skill](https://github.com/Jakeschincariol/youtube-agent-skill) (MIT).
한국판: 방구석프로(bangpro.ai.kr). 설명서 한국어화, 후킹 공식 21개 한국어 이름·예시·패턴 추가,
후킹 채점·제목 검사·편집 구간·챕터 도구의 한국어 처리 추가.
