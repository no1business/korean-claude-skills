# 방구석 모션 키트 (PPT Motion Kit)

투자 유치·지원사업 발표용으로, 차트가 살아 움직이는 키노트급 발표자료를 클로드로 만드는 디자인 시스템 키트입니다.
만든 곳: 방구석 프로 (@bangpro_ai · bangpro.ai.kr) · 무료 배포

---

## 클로드에게 (이 키트를 받은 클로드가 읽는 부분)

이 폴더는 **디자인 시스템의 원본**입니다. 사용자가 "이 키트로 디자인 시스템 만들어줘"라고 하면 아래 1번을, "이 디자인 시스템으로 발표자료 만들어줘"라고 하면 2번을 따르세요.

### 1. 디자인 시스템 만들기
- **Design System** 아티팩트를 새로 만들고 이름은 `방구석 모션 키트`로 합니다.
- `tokens.json`은 **값을 바꾸지 말고 그대로** 넣습니다 (이미 Design System 형식의 목록 구조입니다).
- `fonts/`의 Pretendard Black·ExtraBold·Medium 세 파일을 글꼴로 넣습니다 (`fonts/OFL.txt` 라이선스 동봉, 상업 이용 가능).
- 이 README를 브랜드북(`README.md`)으로 씁니다. "클로드에게" 부분도 지우지 말고 그대로 두세요. 덱을 만드는 클로드가 이 규칙을 읽어야 합니다.
- `charts/`의 8개 파일을 각각 컴포넌트로 등록합니다. `components/<이름>/preview.html`에 **파일 내용을 한 글자도 바꾸지 말고** 넣고, 첫 줄에만 카드 주석을 붙입니다.

  | 파일 | 컴포넌트 이름 | 쓰는 곳 |
  |---|---|---|
  | bg.html | MotionBackground | 모든 슬라이드의 움직이는 배경 (빛 번짐·원근 그리드·입자) |
  | counter.html | MotionCounter | 핵심 숫자 1~3개 (카운트업) |
  | bar-v.html | MotionBarV | 분기·연도별 성장 (세로 막대) |
  | line.html | MotionLine | 추세, 우리 vs 업계 (선) |
  | bar-h.html | MotionBarH | 항목 순위·비교 (가로 막대) |
  | compare.html | MotionCompare | 전·후, 비용 절감 (두 막대 + 도장) |
  | treemap.html | MotionTreemap | 매출 구성·시장 규모 (블록) |
  | donut.html | MotionDonut | 비율 (도넛 + 가운데 숫자) |

- `templates/`의 슬라이드 6종(cover, kpi, chart, statement, split, closing)은 레이아웃 예시입니다. 시스템 안에 같은 경로로 넣어두세요.

### 2. 이 디자인 시스템으로 발표 덱 만들기 (Slides)
**모든 슬라이드는 같은 뼈대**로 만듭니다. `templates/`의 예시를 그대로 따라 하세요.

1. `<section>` 배경: 어두운 기본 `radial-gradient(circle at 78% 18%, #3A2A06 0%, #07080C 58%)` (차트 슬라이드는 `#1E1A10 → #05060A`), 강조 슬라이드는 `radial-gradient(circle at 30% 20%, #FFE27A 0%, #FFB300 70%)`.
2. **첫 번째 자식 = 움직이는 배경**: MotionBackground 전체를 `<x-embed style="position:absolute;left:0px;top:0px;width:1920px;height:1080px">`로 넣습니다. `mode`는 표지·지표·마무리 `'night'`, 차트 슬라이드 `'deep'`, 강조 슬라이드 `'gold'`(grid:false). `glowX/glowY`를 슬라이드마다 조금씩 바꾸면 단조롭지 않습니다.
3. 상단 라벨(알약): `01 · TRACTION`처럼 번호+영문 대문자, 노랑 글자, 노랑 테두리 알약.
4. 제목: `Pretendard ExtraBold` 80px, 결론 문장, 핵심 단어만 `<span style="color:#FFC633">`.
5. **유리 카드** 위에 차트: 카드 `<div>` (아래 스타일)를 먼저 놓고, 그 위에 차트 `<x-embed>`를 카드보다 안쪽(가로 40~80px, 세로 30~40px)으로 겹칩니다.
   `background:linear-gradient(180deg, rgba(255,255,255,0.075) 0%, rgba(255,255,255,0.02) 100%);border:1px solid rgba(255,255,255,0.11);border-radius:36px;box-shadow:0 40px 90px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.12);backdrop-filter:blur(18px)`
6. 푸터 한 줄: 왼쪽 `회사 · 행사 · 출처`, 오른쪽 `03 / 10` (24px, #7C818C, bottom 64px).
7. 표지·마무리 큰 제목: `Pretendard Black` 150px, 첫 줄은 흰색 그라데이션 글자, 둘째 줄(결론)은 금색 그라데이션 글자.
   - 흰색: `background:linear-gradient(180deg, #FFFFFF 35%, #A9AEB9 100%);background-clip:text;-webkit-text-fill-color:transparent`
   - 금색: `background:linear-gradient(180deg, #FFF1C2 0%, #FFC633 45%, #FF9A0A 100%);background-clip:text;-webkit-text-fill-color:transparent`

**차트 넣는 법**
- 컴포넌트의 `preview.html`에서 첫 줄 카드 주석을 뺀 **문서 전체**를 `<x-embed>…</x-embed>` 안에 그대로 넣고, 맨 위 `const D = { … }` 블록만 고칩니다 (숫자·라벨·단위). 어두운 슬라이드는 `theme: 'dark'`.
- `<x-embed>`는 `<section>`의 **직속 자식**, `position:absolute` + left/top/width/height. `<div>` 안에 넣으면 안 됩니다. 한 슬라이드 최대 8개, 하나당 16KB 이하(키트 파일은 모두 14KB 이하).
- 차트는 슬라이드가 나타날 때마다 처음부터 다시 움직이고, 강조 막대에는 빛이 훑고 지나갑니다.
- 권장 위치: 유리 카드 `left:128 top:380~400 width:1664 height:480~540` / 차트 `left:200 top:420 width:1520 height:420~480`. 도넛은 오른쪽 절반(카드 left 940, width 852).
- 제목에 `data-build-in="rise"`, 카드에 `"rise"`, 차트에 `"fade"`, 슬라이드에 `data-transition="fade"`(강조 슬라이드는 `"push"`).
- 수치는 사용자가 준 것만 씁니다. 없으면 `[__]`로 비워두고 알려주세요. 통계를 지어내지 마세요.

---

## 브랜드 기초

### 톤
- **제목은 주제가 아니라 결론입니다.** "매출 현황"(X) → "매출은 분기마다 두 배씩 뛰었습니다"(O).
- 한 슬라이드에 메시지 하나. 글머리표 대신 큰 숫자, 움직이는 차트, 한 줄 강조를 씁니다.
- 덱 흐름 예시(투자 유치 10장): 표지 → 핵심 지표 → 성장 → 재방문/유지 → 강조(비결) → 효율 → 비용 → 매출 구성 → 고객 → 요청.

### 색
- 기본은 **어두운 프리미엄**입니다: 바탕 `#07080C`, 글자 `#F6F3EC`, 보조 글자 `#A9AEB9`, 푸터 `#7C818C`.
- **금색(방구석 노랑 `#FFC633`)은 강조에만** 씁니다: 제목 속 핵심 단어, 알약, 강조 차트, 덱당 1~2장의 노란 강조 슬라이드.
- 차트는 **강조 하나만 금색으로 빛나고 나머지는 유리 회색**입니다. 두 번째 계열이 필요하면 파랑 `#7EA2FF`.
- 밝은 테마(Paper `#F5F2EA`)도 tokens.json에 있지만, 발표 덱은 어두운 테마를 기본으로 합니다.

### 글꼴
- **굵고 힘 있게.** 표지·강조·큰 숫자 `Pretendard Black`, 제목·라벨·알약 `Pretendard ExtraBold`, 본문·푸터 `Pretendard Medium`.
- 세 글꼴은 파일 자체가 굵기를 가지고 있으므로 `font-weight:400`으로 둡니다(겹쳐 굵어지는 것 방지).
- 크기: 150~170 (표지·강조, 자간 -7px) / 80 (제목, 자간 -3px) / 40~44 (부제) / 32 (본문) / 24~26 (라벨·푸터). 24px보다 작은 글자는 쓰지 않습니다.
- 차트 숫자는 차트 파일 안에 굵은 숫자 글꼴이 들어 있습니다.

### 여백과 모양
- 슬라이드 여백 128px, 푸터 bottom 64px.
- 유리 카드 모서리 36px, 막대 16px, 알약 999px.

---

## 폴더 구성
```
ppt-motion-kit/
├─ README.md          ← 지금 이 파일 (브랜드북 + 클로드 규칙)
├─ tokens.json        ← 색·글꼴·간격·모서리 (Design System 형식)
├─ fonts/             ← Pretendard Black·ExtraBold·Medium + 라이선스(OFL)
├─ charts/            ← 움직이는 배경 1 + 차트 7 (x-embed용, const D만 수정)
└─ templates/         ← 슬라이드 레이아웃 6종 예시
```

## 참고
- 발표는 클로드 화면(발표 모드)이나 웹 링크로 하면 차트와 배경이 그대로 움직입니다. PPTX·PDF로 내보내면 움직임 없이 마지막 화면으로 저장됩니다.

## 라이선스
- Pretendard: SIL Open Font License 1.1 (fonts/OFL.txt)
- 차트·템플릿·README: 개인·회사 발표에 자유롭게 수정해서 쓰셔도 됩니다. 키트 자체를 다시 판매하는 것만 금지합니다.
